import { SmartAPI } from "smartapi-javascript";
import type { User } from "@shared/schema";

export class AngelOneAPI {
  private api: any;
  private token: string | null = null;

  constructor(private credentials: Pick<User, "angelOneApiKey" | "angelOneClientId" | "angelOnePassword">) {
    this.api = new SmartAPI({
      api_key: credentials.angelOneApiKey
    });
  }

  async connect() {
    try {
      const { data } = await this.api.generateSession(
        this.credentials.angelOneClientId,
        this.credentials.angelOnePassword
      );
      this.token = data.jwtToken;
      return true;
    } catch (error) {
      console.error("Angel One connection error:", error);
      throw new Error("Failed to connect to Angel One");
    }
  }

  async getQuote(symbol: string) {
    if (!this.token) {
      throw new Error("Not connected to Angel One");
    }

    try {
      const data = await this.api.getQuotes(symbol);
      return {
        symbol,
        ltp: data.ltp,
        volume: data.volume,
        change: data.change
      };
    } catch (error) {
      console.error("Quote fetch error:", error);
      throw new Error(`Failed to fetch quote for ${symbol}`);
    }
  }

  async placeOrder(symbol: string, quantity: number, side: 'BUY' | 'SELL') {
    if (!this.token) {
      throw new Error("Not connected to Angel One");
    }

    try {
      const order = await this.api.placeOrder({
        variety: "NORMAL",
        tradingsymbol: symbol,
        symboltoken: "1594", // This should be dynamically fetched
        transactiontype: side,
        exchange: "NSE",
        ordertype: "MARKET",
        producttype: "INTRADAY",
        duration: "DAY",
        quantity: quantity.toString()
      });

      return order;
    } catch (error) {
      console.error("Order placement error:", error);
      throw new Error(`Failed to place ${side} order for ${symbol}`);
    }
  }
}
