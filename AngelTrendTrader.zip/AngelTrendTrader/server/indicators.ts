export interface SupertrendResult {
  value: number;
  signal: 'BUY' | 'SELL' | null;
}

export function calculateSupertrend(
  high: number[],
  low: number[],
  close: number[],
  period: number = 10,
  multiplier: number = 3
): SupertrendResult {
  if (high.length < 2 || low.length < 2 || close.length < 2) {
    return {
      value: close[close.length - 1] || 0,
      signal: null
    };
  }

  // Basic ATR calculation
  const tr: number[] = [];
  for (let i = 1; i < close.length; i++) {
    const hl = high[i] - low[i];
    const hc = Math.abs(high[i] - close[i - 1]);
    const lc = Math.abs(low[i] - close[i - 1]);
    tr.push(Math.max(hl, hc, lc));
  }

  // Calculate ATR with initial value
  const atr = tr.reduce((a, b) => a + b, 0) / (tr.length || 1);

  const lastClose = close[close.length - 1];
  const lastHigh = high[high.length - 1];
  const lastLow = low[low.length - 1];

  // Basic bands
  const basicUpperBand = (lastHigh + lastLow) / 2 + multiplier * atr;
  const basicLowerBand = (lastHigh + lastLow) / 2 - multiplier * atr;

  // Determine trend and signal
  let trend: 'up' | 'down' = lastClose > basicUpperBand ? 'up' : 'down';

  let signal: 'BUY' | 'SELL' | null = null;
  if (close.length >= 2) {
    if (trend === 'up' && close[close.length - 2] <= basicUpperBand) {
      signal = 'BUY';
    } else if (trend === 'down' && close[close.length - 2] >= basicLowerBand) {
      signal = 'SELL';
    }
  }

  return {
    value: trend === 'up' ? basicLowerBand : basicUpperBand,
    signal
  };
}