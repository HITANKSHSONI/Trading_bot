import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { AngelOneAPI } from "./angelone";
import { calculateSupertrend } from "./indicators";
import { updateUserAPISchema } from "@shared/schema";
import { db } from "./db";
import { historicalPrices } from "@shared/schema";
import { desc, eq } from "drizzle-orm";

// Market hours check (IST)
function isMarketOpen(): boolean {
  const now = new Date();
  const ist = new Date(now.getTime() + (5.5 * 60 * 60 * 1000)); // Convert to IST
  const hours = ist.getUTCHours();
  const minutes = ist.getUTCMinutes();
  const day = ist.getUTCDay();

  // Check if it's a weekday and within market hours (9:15 AM to 3:30 PM IST)
  return day > 0 && day < 6 && // Monday to Friday
    ((hours === 9 && minutes >= 15) || // After 9:15 AM
      (hours > 9 && hours < 15) || // 10 AM to 2:59 PM
      (hours === 15 && minutes <= 30)); // Before 3:30 PM
}

async function getLastPrice(symbol: string) {
  const [lastPrice] = await db
    .select()
    .from(historicalPrices)
    .where(eq(historicalPrices.symbol, symbol))
    .orderBy(desc(historicalPrices.timestamp))
    .limit(1);
  return lastPrice;
}

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Price history for each symbol
  const priceHistory: Record<string, { high: number[]; low: number[]; close: number[] }> = {};

  // WebSocket handling for real-time updates
  wss.on('connection', (ws) => {
    ws.on('message', async (message) => {
      try {
        const { type, symbol } = JSON.parse(message.toString());

        if (type === 'subscribe' && symbol) {
          // Initialize price history for new symbols
          if (!priceHistory[symbol]) {
            priceHistory[symbol] = {
              high: [],
              low: [],
              close: []
            };
          }

          const interval = setInterval(async () => {
            if (ws.readyState === ws.OPEN) {
              let marketData;
              const marketOpen = isMarketOpen();

              if (marketOpen) {
                try {
                  // Attempt to get real market data
                  const user = await storage.getUser(1); // This should be the authenticated user's ID
                  if (user?.angelOneApiKey) {
                    const api = new AngelOneAPI(user);
                    await api.connect();
                    marketData = await api.getQuote(symbol);

                    // Store historical price
                    await db.insert(historicalPrices).values({
                      symbol: marketData.symbol,
                      price: marketData.ltp,
                      volume: marketData.volume,
                      timestamp: new Date()
                    });
                  }
                } catch (error) {
                  console.error('Failed to fetch real market data:', error);
                }
              }

              // If market is closed or error occurred, use last known price
              if (!marketData) {
                const lastPrice = await getLastPrice(symbol);
                if (lastPrice) {
                  marketData = {
                    symbol,
                    ltp: lastPrice.price,
                    volume: lastPrice.volume,
                    change: 0,
                    lastUpdated: lastPrice.timestamp
                  };
                } else {
                  // If no historical data, notify client
                  ws.send(JSON.stringify({
                    error: "No price data available"
                  }));
                  return;
                }
              }

              // Only calculate signals during market hours
              let signal = null;
              if (marketOpen) {
                // Update price history
                const history = priceHistory[symbol];
                history.high.push(marketData.ltp * 1.001);
                history.low.push(marketData.ltp * 0.999);
                history.close.push(marketData.ltp);

                // Keep last 20 points
                if (history.high.length > 20) {
                  history.high.shift();
                  history.low.shift();
                  history.close.shift();
                }

                // Calculate Supertrend
                const supertrend = calculateSupertrend(
                  history.high,
                  history.low,
                  history.close
                );
                signal = supertrend.signal;
              }

              ws.send(JSON.stringify({
                ...marketData,
                signal,
                marketOpen
              }));
            } else {
              clearInterval(interval);
            }
          }, 1000);

          // Clean up on client disconnect
          ws.on('close', () => {
            clearInterval(interval);
          });
        }
      } catch (error) {
        console.error('WebSocket error:', error);
      }
    });
  });

  // Keep existing API routes unchanged
  app.post("/api/credentials", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const credentials = updateUserAPISchema.parse(req.body);
      const api = new AngelOneAPI(credentials);
      await api.connect(); // Test connection

      await storage.updateUserCredentials(req.user.id, credentials);
      res.sendStatus(200);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  app.get("/api/quote/:symbol", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const user = await storage.getUser(req.user.id);
      if (!user?.angelOneApiKey) {
        return res.status(400).json({ message: "Angel One API not configured" });
      }

      const api = new AngelOneAPI(user);
      await api.connect();
      const quote = await api.getQuote(req.params.symbol);
      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  app.post("/api/order", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    // Only allow orders during market hours
    if (!isMarketOpen()) {
      return res.status(400).json({ message: "Market is closed" });
    }

    const { symbol, quantity, side } = req.body;

    try {
      const user = await storage.getUser(req.user.id);
      if (!user?.angelOneApiKey) {
        return res.status(400).json({ message: "Angel One API not configured" });
      }

      const api = new AngelOneAPI(user);
      await api.connect();
      const order = await api.placeOrder(symbol, quantity, side);
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  return httpServer;
}