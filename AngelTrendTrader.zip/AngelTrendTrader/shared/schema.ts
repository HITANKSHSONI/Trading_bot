import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  angelOneApiKey: text("angel_one_api_key"),
  angelOneClientId: text("angel_one_client_id"),
  angelOnePassword: text("angel_one_password")
});

export const positions = pgTable("positions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  symbol: text("symbol").notNull(),
  quantity: integer("quantity").notNull(),
  entryPrice: integer("entry_price").notNull(),
  currentPrice: integer("current_price"),
  pnl: integer("pnl"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow()
});

export const historicalPrices = pgTable("historical_prices", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  price: integer("price").notNull(),
  volume: integer("volume").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true
});

export const updateUserAPISchema = createInsertSchema(users).pick({
  angelOneApiKey: true,
  angelOneClientId: true,
  angelOnePassword: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUserAPI = z.infer<typeof updateUserAPISchema>;
export type User = typeof users.$inferSelect;
export type Position = typeof positions.$inferSelect;
export type HistoricalPrice = typeof historicalPrices.$inferSelect;

export interface MarketData {
  symbol: string;
  ltp: number;
  volume: number;
  change: number;
  signal?: 'BUY' | 'SELL' | null;
  isSimulated?: boolean;
  lastUpdated?: Date;
}