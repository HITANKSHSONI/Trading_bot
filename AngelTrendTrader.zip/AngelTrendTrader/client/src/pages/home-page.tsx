import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMarketData } from "@/hooks/use-market";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, ArrowUpCircle, ArrowDownCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Market hours check (IST)
function isMarketOpen(): boolean {
  const now = new Date();
  const ist = new Date(now.getTime() + (5.5 * 60 * 60 * 1000)); // Convert to IST
  const hours = ist.getUTCHours();
  const minutes = ist.getUTCMinutes();
  const day = ist.getUTCDay();

  return day > 0 && day < 6 && // Monday to Friday
    ((hours === 9 && minutes >= 15) || // After 9:15 AM
      (hours > 9 && hours < 15) || // 10 AM to 2:59 PM
      (hours === 15 && minutes <= 30)); // Before 3:30 PM
}

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [symbol, setSymbol] = useState("RELIANCE");
  const { data: marketData, error } = useMarketData(symbol);
  const { toast } = useToast();
  const marketOpen = isMarketOpen();

  const handleTrade = async (side: 'BUY' | 'SELL') => {
    if (!marketOpen) {
      toast({
        title: "Market Closed",
        description: "Trading is only available during market hours (9:15 AM to 3:30 PM IST, Monday to Friday)",
        variant: "destructive"
      });
      return;
    }

    try {
      await apiRequest('POST', '/api/order', {
        symbol,
        quantity: 1,
        side
      });

      toast({
        title: "Order Placed",
        description: `Successfully placed ${side} order for ${symbol}`,
      });
    } catch (error) {
      toast({
        title: "Order Failed",
        description: (error as Error).message,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">TradingAI</h1>
          <div className="flex items-center gap-4">
            <span>{user?.username}</span>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              <span className="text-sm">
                Market Hours: 9:15 AM - 3:30 PM IST (Mon-Fri)
              </span>
            </div>
            <Badge variant={marketOpen ? "outline" : "destructive"}>
              {marketOpen ? "Market Open" : "Market Closed"}
            </Badge>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Market Watch</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <Input
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                  placeholder="Enter symbol (e.g. RELIANCE)"
                />
              </div>

              {error ? (
                <div className="flex items-center gap-2 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <span>{error}</span>
                </div>
              ) : marketData ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Price</div>
                      <div className="text-2xl font-bold">₹{marketData.ltp.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Change</div>
                      <div className={`text-2xl font-bold ${marketData.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {marketData.change.toFixed(2)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Volume</div>
                      <div className="text-2xl font-bold">{marketData.volume.toLocaleString()}</div>
                    </div>
                    {marketOpen && (
                      <div>
                        <div className="text-sm text-muted-foreground">Signal</div>
                        <div className="flex items-center gap-2">
                          {marketData.signal === 'BUY' && (
                            <>
                              <ArrowUpCircle className="h-6 w-6 text-green-500" />
                              <Badge variant="outline" className="border-green-500 text-green-500">BUY</Badge>
                            </>
                          )}
                          {marketData.signal === 'SELL' && (
                            <>
                              <ArrowDownCircle className="h-6 w-6 text-red-500" />
                              <Badge variant="outline" className="border-red-500 text-red-500">SELL</Badge>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {!marketOpen && (
                    <div className="flex items-center gap-2 bg-yellow-50 border border-yellow-200 p-3 rounded-md">
                      <AlertCircle className="h-5 w-5 text-yellow-500" />
                      <div className="text-sm text-yellow-700">
                        <p className="font-medium">Market is closed</p>
                        {marketData.lastUpdated && (
                          <p>Last updated: {new Date(marketData.lastUpdated).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-4">
                    <Button
                      onClick={() => handleTrade('BUY')}
                      className="flex-1"
                      variant="default"
                      disabled={!marketOpen}
                    >
                      Buy
                    </Button>
                    <Button
                      onClick={() => handleTrade('SELL')}
                      className="flex-1"
                      variant="destructive"
                      disabled={!marketOpen}
                    >
                      Sell
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  Loading market data...
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}