import { useEffect, useState } from 'react';
import { type MarketData } from '@shared/schema';

export function useMarketData(symbol: string) {
  const [data, setData] = useState<MarketData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'subscribe', symbol }));
    };

    ws.onmessage = (event) => {
      try {
        const marketData = JSON.parse(event.data);
        setData(marketData);
        setError(null);
      } catch (err) {
        setError('Failed to parse market data');
      }
    };

    ws.onerror = () => {
      setError('WebSocket connection failed');
    };

    return () => {
      ws.close();
    };
  }, [symbol]);

  return { data, error };
}
